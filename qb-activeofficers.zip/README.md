# qb-activeofficers
Advanced Active Officers by NevoG converted to QBCore

Requirements:
- qb-core
- qb-policejob

Commands:
- /plist 0 - Drag Menu
- /plist - Toggle Menu
- /callsign [callsign] - To set your callsign

Buttons:
- = for Drag Menu
- \- for Toggle Menu

Preview:

![unknown](https://user-images.githubusercontent.com/60448180/131723399-0a85b621-c4bb-4b17-8f62-d4ba5b44ef25.png)
