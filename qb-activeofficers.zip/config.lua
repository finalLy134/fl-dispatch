Config = {}

-- LSPD Command Callsigns --
Config.Command_Min = '200'
Config.Command_Max = '220'

-- LSPD Detective Callsigns --
Config.Detective_Min = '300'
Config.Detective_Max = '330'

-- S.W.A.T Callsigns --
Config.Swat_Min = '350'
Config.Swat_Max = '360'

-- BCSO Sheriffs Callsigns --
Config.Bcso_Min = '400'
Config.Bcso_Max = '430'

-- SASP Troopers Callsigns --
Config.Troopers_Min = '450'
Config.Troopers_Max = '470'

-- SASPR Rangers Callsigns --
Config.Rangers_Min = '500'
Config.Rangers_Max = '550'
